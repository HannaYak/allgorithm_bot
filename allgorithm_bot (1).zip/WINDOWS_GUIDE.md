# 🪟 Инструкция для Windows 11 - Allgorithm Telegram Bot

Привет! Это инструкция специально для Windows 11. Всё просто и понятно 🙂

---

## 📋 Что нужно сделать в начале?

Перед тем как начать, нужно установить несколько программ.

### Шаг 0: Установить необходимые программы

#### 1️⃣ Установить Node.js

Node.js — это программа, которая позволяет запускать JavaScript код.

**Как установить:**

1. Откройте https://nodejs.org
2. Нажмите на зелёную кнопку "LTS" (это стабильная версия)
3. Скачается файл `node-vXX.XX.X.msi`
4. Откройте файл и нажимайте "Next" → "Next" → "Finish"
5. Перезагрузите компьютер

**Проверить установку:**

1. Откройте **Command Prompt** (нажмите `Win + R`, напишите `cmd`, нажмите Enter)
2. Напишите:
```
node --version
```
3. Должно показать что-то типа: `v20.10.0`

#### 2️⃣ Установить Git

Git — это программа для управления кодом.

**Как установить:**

1. Откройте https://git-scm.com/download/win
2. Скачается файл `Git-2.XX.X-64-bit.exe`
3. Откройте файл и нажимайте "Next" → "Next" → "Finish"
4. Перезагрузите компьютер

**Проверить установку:**

1. Откройте Command Prompt
2. Напишите:
```
git --version
```
3. Должно показать что-то типа: `git version 2.40.0`

#### 3️⃣ Установить pnpm

pnpm — это менеджер пакетов (помощник для скачивания библиотек).

**Как установить:**

1. Откройте Command Prompt
2. Напишите:
```
npm install -g pnpm
```
3. Подождите, пока установится
4. Проверьте:
```
pnpm --version
```
Должно показать что-то типа: `8.10.0`

---

## 🚀 Шаг 1: Скачать код бота на свой компьютер

### 1.1 Скачать папку с кодом

Я уже создал весь код для вас. Нужно скачать его:

1. Откройте папку, где вы хотите хранить проект (например, `C:\Users\YourName\Documents`)
2. Откройте Command Prompt в этой папке:
   - Нажмите `Shift + Right Click` в пустом месте папки
   - Выберите "Open PowerShell window here" (или "Open Command Prompt here")
3. Напишите:
```
git clone https://github.com/YOUR_USERNAME/allgorithm_bot.git
cd allgorithm_bot
```

Если у вас нет GitHub репозитория, просто скопируйте папку проекта на свой компьютер.

### 1.2 Установить зависимости

В Command Prompt (в папке `allgorithm_bot`) напишите:

```
pnpm install
```

Это скачает все необходимые библиотеки. Может занять 2-3 минуты.

---

## 🔑 Шаг 2: Получить токен Telegram бота

### 2.1 Создать бота в BotFather

1. Откройте Telegram
2. Найдите бота `@BotFather`
3. Напишите `/newbot`
4. Следуйте инструкциям:
   - Придумайте имя для бота (например, "AllgorithmBot")
   - Придумайте username (например, "allgorithm_bot_123")
5. BotFather вам даст **токен** (выглядит так: `123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11`)
6. **Скопируйте этот токен** - он вам нужен дальше

---

## 📝 Шаг 3: Создать файл `.env.local`

Этот файл хранит секретные данные (токены, пароли и т.д.).

### 3.1 Создать файл

1. Откройте папку проекта (`allgorithm_bot`)
2. Нажмите `Right Click` в пустом месте
3. Выберите "New" → "Text Document"
4. Назовите файл `.env.local` (важно: точка в начале!)
5. Откройте файл в блокноте (Notepad)

### 3.2 Добавить содержимое

Вставьте в файл:

```env
# Telegram Bot
TELEGRAM_BOT_TOKEN=вставьте_ваш_токен_сюда

# Database (оставьте как есть для локального тестирования)
DATABASE_URL=mysql://localhost/allgorithm

# Node Environment
NODE_ENV=development
```

**Замените `вставьте_ваш_токен_сюда` на токен, который вам дал BotFather!**

Пример:
```env
TELEGRAM_BOT_TOKEN=123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11
```

### 3.3 Сохранить файл

1. Нажмите `Ctrl + S`
2. Закройте блокнот

---

## 🧪 Шаг 4: Запустить бота локально (тест)

### 4.1 Запустить сервер

1. Откройте Command Prompt в папке проекта
2. Напишите:

```
pnpm dev
```

Должно вывести что-то типа:

```
[OAuth] Initialized with baseURL: https://api.manus.im
[Bot] Polling started
Server running on http://localhost:3000/
```

**Если видите это - всё работает! ✅**

### 4.2 Протестировать в Telegram

1. Откройте Telegram
2. Найдите своего бота (по username, который вы дали)
3. Напишите `/start`
4. Должно появиться приветствие и кнопка "Пройти анкету"

**Если работает - отлично! 🎉**

### 4.3 Остановить бота

Когда закончите тестировать:

1. В Command Prompt нажмите `Ctrl + C`
2. Напишите `Y` и нажмите Enter

---

## 💳 Шаг 5: Добавить Stripe (оплата)

### 5.1 Зарегистрироваться на Stripe

1. Откройте https://stripe.com
2. Нажмите "Sign up"
3. Заполните данные
4. Подтвердите email

### 5.2 Получить API ключи

1. Войдите в Stripe Dashboard
2. Слева нажмите "Developers" → "API keys"
3. Скопируйте:
   - **Publishable key** (начинается с `pk_test_`)
   - **Secret key** (начинается с `sk_test_`)

### 5.3 Добавить ключи в `.env.local`

1. Откройте файл `.env.local` в блокноте
2. Добавьте в конец:

```env
STRIPE_SECRET_KEY=sk_test_вставьте_ваш_ключ_сюда
STRIPE_PUBLIC_KEY=pk_test_вставьте_ваш_ключ_сюда
```

3. Сохраните файл (`Ctrl + S`)

---

## 🎮 Шаг 6: Добавить игровые функции

### 6.1 Открыть файл с кодом

1. Откройте папку проекта
2. Откройте папку `server` → `bot`
3. Найдите файл `handlers.ts`
4. Откройте его в редакторе (например, VS Code)

### 6.2 Добавить кнопку "Дай тему!"

Найдите в файле строку:
```typescript
bot.action('game_talk_toast', async (ctx) => {
```

Замените её на:

```typescript
bot.action('game_talk_toast', async (ctx) => {
  await ctx.reply('🍽️ **Talk & Toast**\n\n8 человек, один большой стол, викторина из фактов участников.', {
    reply_markup: {
      inline_keyboard: [
        [{ text: '🎯 Дай тему!', callback_data: 'topic_event_1' }],
        [{ text: '📋 Правила', callback_data: 'talk_toast_rules' }],
        [{ text: '⬅️ Назад', callback_data: 'games' }],
      ],
    },
    parse_mode: 'Markdown',
  });
  await ctx.answerCbQuery();
});
```

### 6.3 Добавить обработчик для "Дай тему!"

В конце файла (перед последней скобкой) добавьте:

```typescript
  // Кнопка "Дай тему!" для Talk & Toast
  bot.action(/topic_event_(\d+)/, async (ctx) => {
    const topics = [
      '🎬 Какой твой любимый фильм и почему?',
      '✈️ Куда бы ты хотел поехать в отпуск?',
      '🍕 Какое твоё любимое блюдо?',
      '📚 Какую последнюю книгу ты читал?',
      '🎵 Какой твой любимый исполнитель?',
      '🏃 Чем ты занимаешься в свободное время?',
      '🌍 Если бы ты мог жить в любой стране, какую выбрал бы?',
      '💭 Какой был самый интересный день в твоей жизни?',
    ];

    const randomTopic = topics[Math.floor(Math.random() * topics.length)];

    await ctx.reply(
      `🎯 **Тема для разговора:**\n\n${randomTopic}`,
      { parse_mode: 'Markdown' }
    );

    await ctx.answerCbQuery();
  });

  // Обработчик для правил Talk & Toast
  bot.action('talk_toast_rules', async (ctx) => {
    await ctx.reply(
      '📖 **Правила Talk & Toast**\n\n' +
      '1️⃣ Все сидят за одним столом\n' +
      '2️⃣ Можно нажать "Дай тему!" для случайного вопроса\n' +
      '3️⃣ За 15 минут до конца — викторина\n' +
      '4️⃣ Викторина из фактов анкет участников\n' +
      '5️⃣ Длительность: 2 часа\n\n' +
      '<!-- PLACEHOLDER: Добавь свои правила здесь -->',
      { parse_mode: 'Markdown' }
    );
    await ctx.answerCbQuery();
  });
```

### 6.4 Сохранить файл

Нажмите `Ctrl + S`

---

## 🚀 Шаг 7: Развернуть на Render.com (облако)

### 7.1 Создать GitHub репозиторий

1. Откройте https://github.com
2. Нажмите "Sign up" и создайте аккаунт
3. Нажмите "+" → "New repository"
4. Назовите его `allgorithm_bot`
5. Нажмите "Create repository"

### 7.2 Залить код на GitHub

1. Откройте Command Prompt в папке проекта
2. Напишите:

```
git init
git add .
git commit -m "Initial commit - Allgorithm bot"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/allgorithm_bot.git
git push -u origin main
```

Замените `YOUR_USERNAME` на ваш username на GitHub.

### 7.3 Создать Web Service на Render

1. Откройте https://render.com
2. Нажмите "Sign up" и выберите "Sign up with GitHub"
3. Авторизуйтесь
4. Нажмите "New +" → "Web Service"
5. Выберите репозиторий `allgorithm_bot`
6. Заполните:
   - **Name:** `allgorithm-bot`
   - **Build Command:** `pnpm install && pnpm build`
   - **Start Command:** `pnpm start`
   - **Environment:** Node

7. Нажмите "Create Web Service"

### 7.4 Добавить переменные окружения

1. На странице сервиса нажмите "Environment"
2. Добавьте переменные:

```
TELEGRAM_BOT_TOKEN=ваш_токен
DATABASE_URL=ваша_база_данных
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLIC_KEY=pk_test_...
NODE_ENV=production
```

3. Нажмите "Save"

### 7.5 Получить URL приложения

После развёртывания Render даст вам URL типа:
```
https://allgorithm-bot.onrender.com
```

### 7.6 Установить webhook для Telegram

1. Откройте браузер
2. Перейдите по ссылке (замените токен и URL):

```
https://api.telegram.org/bot123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11/setWebhook?url=https://allgorithm-bot.onrender.com/api/telegram/webhook
```

Должно вернуться:
```json
{"ok":true,"result":true,"description":"Webhook was set"}
```

**Готово! Ваш бот теперь работает в облаке 24/7! 🎉**

---

## 📝 Что нужно заполнить вручную?

### 1. Правила игр

Откройте `server/bot/handlers.ts`

Найдите:
```typescript
'<!-- PLACEHOLDER: Добавь правила здесь -->\n' +
'Правила будут добавлены администратором.'
```

Замените на свои правила.

### 2. Приветственное сообщение

Найдите:
```typescript
'👋 Добро пожаловать в Allgorithm!\n\n'
```

Измените текст на свой.

---

## ✅ Чеклист для Windows

- [ ] Установлен Node.js (проверка: `node --version`)
- [ ] Установлен Git (проверка: `git --version`)
- [ ] Установлен pnpm (проверка: `pnpm --version`)
- [ ] Скачан код проекта
- [ ] Установлены зависимости (`pnpm install`)
- [ ] Получен токен от BotFather
- [ ] Создан файл `.env.local` с токеном
- [ ] Запущен бот (`pnpm dev`)
- [ ] Протестирован в Telegram (`/start`)
- [ ] Добавлены Stripe ключи
- [ ] Добавлены игровые функции
- [ ] Создан GitHub репозиторий
- [ ] Развёрнуто на Render.com
- [ ] Установлен webhook для Telegram

---

## 🆘 Решение проблем на Windows

### Ошибка: "pnpm is not recognized"

**Решение:**
1. Перезагрузите компьютер
2. Откройте новый Command Prompt
3. Попробуйте снова

### Ошибка: "git is not recognized"

**Решение:**
1. Перезагрузите компьютер
2. Откройте новый Command Prompt
3. Попробуйте снова

### Ошибка: "Bot token is invalid"

**Решение:**
1. Проверьте, что токен правильно скопирован в `.env.local`
2. Убедитесь, что нет пробелов в начале или конце
3. Перезагрузите Command Prompt

### Ошибка: "Cannot find module"

**Решение:**
1. Откройте Command Prompt в папке проекта
2. Напишите: `pnpm install`
3. Подождите, пока установятся зависимости

### Бот не отвечает в Telegram

**Решение:**
1. Проверьте, что `pnpm dev` запущен
2. Проверьте, что токен правильный
3. Проверьте логи в Command Prompt

---

## 📚 Полезные команды для Windows

| Команда | Что делает |
|---------|-----------|
| `pnpm dev` | Запустить бота локально |
| `pnpm build` | Собрать код для развёртывания |
| `pnpm start` | Запустить собранный код |
| `git status` | Показать статус репозитория |
| `git add .` | Добавить все файлы для коммита |
| `git commit -m "сообщение"` | Создать коммит |
| `git push` | Загрузить на GitHub |

---

## 🎓 Дополнительные ресурсы

- [Node.js документация](https://nodejs.org/docs/)
- [Git для Windows](https://git-scm.com/download/win)
- [Telegram Bot API](https://core.telegram.org/bots/api)
- [Telegraf документация](https://telegraf.js.org/)
- [Stripe документация](https://stripe.com/docs)
- [Render документация](https://render.com/docs)

---

**Удачи! 🚀**

Если у вас есть вопросы, спросите меня!
