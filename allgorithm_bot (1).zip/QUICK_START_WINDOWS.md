# 🚀 Быстрый старт для Windows - 5 минут

Это самая короткая инструкция. Просто следуй по шагам!

---

## ✅ Что ты уже сделал:

- ✅ Установил Node.js
- ✅ Установил Git
- ✅ Установил pnpm
- ✅ Создал папку `C:\Users\hanna\allgorithm_bot`

**Отлично! Теперь просто скопируй файлы и запусти бота.**

---

## 📥 Шаг 1: Скачать все файлы проекта (2 минуты)

### 1.1 Откройте браузер и перейдите сюда:
```
https://github.com/manusai/allgorithm_bot
```

### 1.2 Нажмите зелёную кнопку "Code"

![Кнопка Code](https://imgur.com/a/code-button)

### 1.3 Выберите "Download ZIP"

Скачается файл `allgorithm_bot-main.zip`

### 1.4 Распакуйте файлы

1. Откройте папку `C:\Users\hanna\`
2. Найдите файл `allgorithm_bot-main.zip`
3. Нажмите Right Click → "Extract All..."
4. Выберите папку `C:\Users\hanna\`
5. Нажмите "Extract"

Получится папка `allgorithm_bot-main`

### 1.5 Переименуйте папку

1. Нажмите Right Click на папку `allgorithm_bot-main`
2. Выберите "Rename"
3. Переименуйте в `allgorithm_bot` (удалите `-main`)

**Готово! Все файлы на месте! ✅**

---

## 🔧 Шаг 2: Установить зависимости (2 минуты)

### 2.1 Откройте Command Prompt в папке проекта

1. Откройте папку `C:\Users\hanna\allgorithm_bot`
2. Нажмите Shift + Right Click в пустом месте
3. Выберите "Open PowerShell window here" (или "Open Command Prompt here")

### 2.2 Напишите команду

```
pnpm install
```

Подождите 2-3 минуты, пока установятся все библиотеки.

Когда закончится, должно написать:
```
Done in 2.5s
```

**Готово! Зависимости установлены! ✅**

---

## 🤖 Шаг 3: Запустить бота (1 минута)

### 3.1 В том же Command Prompt напишите:

```
pnpm dev
```

Должно вывести:
```
[Bot] Polling started
Server running on http://localhost:3000/
```

**Готово! Бот запущен! ✅**

---

## 📱 Шаг 4: Протестировать в Telegram (1 минута)

### 4.1 Откройте Telegram

1. Найдите своего бота (по username, который вы дали BotFather)
2. Напишите `/start`
3. Должно появиться приветствие

**Готово! Бот работает! 🎉**

---

## 📤 Шаг 5: Загрузить на GitHub (опционально)

Если хочешь сохранить код на GitHub:

### 5.1 Создай репозиторий на GitHub

1. Откройте https://github.com/new
2. Назовите его `allgorithm_bot`
3. Нажмите "Create repository"

### 5.2 Загрузи файлы

В Command Prompt (в папке проекта) напишите:

```
git init
git add .
git commit -m "Initial commit - Allgorithm bot"
git branch -M main
git remote add origin https://github.com/HannaYak/allgorithm_bot.git
git push -u origin main
```

**Готово! Код на GitHub! ✅**

---

## 🆘 Если что-то не работает

| Ошибка | Решение |
|--------|---------|
| `ERR_PNPM_NO_PKG_MANIFEST` | Убедитесь, что вы в папке `allgorithm_bot` (где есть файл `package.json`) |
| `pnpm is not recognized` | Перезагрузите компьютер и откройте новый Command Prompt |
| Бот не отвечает в Telegram | Проверьте, что `pnpm dev` запущен и показывает "Polling started" |
| `Cannot find module` | Напишите `pnpm install` ещё раз |

---

## 📝 Что дальше?

После того как бот запущен:

1. **Добавь Stripe** (для оплаты) - смотри `WINDOWS_GUIDE.md` Шаг 5
2. **Добавь игровые функции** - смотри `WINDOWS_GUIDE.md` Шаг 6
3. **Развёрни на Render.com** - смотри `WINDOWS_GUIDE.md` Шаг 7

---

**Всё готово! Поздравляю! 🚀**
